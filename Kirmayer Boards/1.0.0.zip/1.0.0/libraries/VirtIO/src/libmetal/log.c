#ifdef VIRTIOCON

#include "libmetal/lib/log.c"

#endif /* VIRTIOCON */
