#ifdef VIRTIOCON

#include "libmetal/lib/io.c"

#endif /* VIRTIOCON */
